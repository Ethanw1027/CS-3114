// On my honor:
// - I have not used source code obtained from another student,
// or any other unauthorized source, either modified or
// unmodified.
//
// - All source code and documentation used in my program is
// either my original work, or was derived by me from the
// source code published in the textbook for this course.
//
// - I have not discussed coding details about this project
// with anyone other than my partner (in the case of a joint
// submission), instructor, ACM/UPE tutors or the TAs assigned
// to this course. I understand that I may discuss the concepts
// of this program with other students, and that another student
// may help me debug my program so long as neither of us writes
// anything during the discussion or modifies any computer file
// during the discussion. I have violated neither the spirit nor
// letter of this restriction.

import student.TestCase;

/**
 * @author Ethan Werner
 * @version 01.28.23
 * 
 *          Tests the methods of the BigNum class
 */
public class BigNumTest extends TestCase {

    // Two BigNum objects used for testing
    private BigNum num1;
    private BigNum num2;

    /**
     * Sets up to test the methods of the BigNum class
     */
    @Override
    public void setUp() {
        num1 = new BigNum("012345");
        num2 = new BigNum();
    }
    

    /**
     * Tests the toString method
     */
    public void testToString() {
        assertEquals(num1.toString(), "12345");
        assertEquals(num2.toString(), "0");
    }


    /**
     * Tests the removeFront method
     */
    public void testRemoveFront() {
        assertFalse(num2.removeFront());
        assertEquals(num2.getSize(), 0);

        num2.addFront(1);
        assertTrue(num2.removeFront());
        assertNull(num2.getHead());
        assertNull(num2.getTail());
        assertEquals(num2.getSize(), 0);

        num2.addFront(1);
        num2.addBack(2);
        num2.addBack(3);
        assertTrue(num2.removeFront());
        assertEquals("2", num2.getHead().getData().toString());
        assertNull(num2.getHead().getPrev());
        assertEquals(num2.getSize(), 2);
    }
    
    
    /**
     * Tests the removeBack method
     */
    public void testRemoveBack() {
        assertFalse(num2.removeBack());
        assertEquals(num2.getSize(), 0);

        num2.addFront(1);
        assertTrue(num2.removeBack());
        assertNull(num2.getHead());
        assertNull(num2.getTail());
        assertEquals(num2.getSize(), 0);

        num2.addFront(1);
        num2.addBack(2);
        num2.addBack(3);
        assertTrue(num2.removeBack());
        assertEquals("1", num2.getHead().getData().toString());
        assertNull(num2.getTail().getNext());
        assertEquals(num2.getSize(), 2);
    }
    
    
    /**
     * Tests the add method
     */
    public void testAdd() {
        assertEquals("12345", num1.add(num2).toString());

        num1 = new BigNum("012345");
        num2 = new BigNum("4321");
        assertEquals("16666", num1.add(num2).toString());

        num1 = new BigNum("12345");
        num2 = new BigNum("54321");
        assertEquals("66666", num1.add(num2).toString());

        num1 = new BigNum("12345");
        num2 = new BigNum("154321");
        assertEquals("166666", num1.add(num2).toString());

        num1 = new BigNum("1");
        num2 = new BigNum("999999999999999");
        assertEquals("1000000000000000", num1.add(num2).toString());

        num1 = new BigNum("1");
        num2 = new BigNum("999999999999999");
        assertEquals("1000000000000000", num2.add(num1).toString());
    }


    /**
     * Tests the multiply method
     */
    public void testMultiply() {
        num2.addFront(1);
        assertEquals("12345", num1.multiply(num2).toString());

        num1 = new BigNum("174");
        num2 = new BigNum("2");
        assertEquals("348", num1.multiply(num2).toString());

        num1 = new BigNum("2");
        num2 = new BigNum("174");
        assertEquals("348", num1.multiply(num2).toString());

        num1 = new BigNum("222221111943827858942359873211");
        num2 = new BigNum("123");
        assertEquals("27333196769090826649910264404953", num1.multiply(num2)
            .toString());

        num1 = new BigNum("222221111943827858942359873211");
        num2 = new BigNum("123");
        assertEquals("27333196769090826649910264404953", num2.multiply(num1)
            .toString());
    }


    /**
     * Tests the exponent method
     */
    public void testExponent() {
        num1 = new BigNum("5");
        num2 = new BigNum("0");
        assertEquals("1", num1.exponent(num2).toString());

        num1 = new BigNum("5");
        num2 = new BigNum("1");
        assertEquals("5", num1.exponent(num2).toString());

        num1 = new BigNum("5");
        num2 = new BigNum("2");
        assertEquals("25", num1.exponent(num2).toString());

        num1 = new BigNum("5");
        num2 = new BigNum("3");
        assertEquals("125", num1.exponent(num2).toString());

        num1 = new BigNum("5");
        num2 = new BigNum("12");
        assertEquals("244140625", num1.exponent(num2).toString());
        
        num1 = new BigNum("1");
        num2 = new BigNum("12");
        assertEquals("1", num1.exponent(num2).toString());
    }
}
