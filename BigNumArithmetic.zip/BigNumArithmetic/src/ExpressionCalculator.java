// On my honor:
// - I have not used source code obtained from another student,
// or any other unauthorized source, either modified or
// unmodified.
//
// - All source code and documentation used in my program is
// either my original work, or was derived by me from the
// source code published in the textbook for this course.
//
// - I have not discussed coding details about this project
// with anyone other than my partner (in the case of a joint
// submission), instructor, ACM/UPE tutors or the TAs assigned
// to this course. I understand that I may discuss the concepts
// of this program with other students, and that another student
// may help me debug my program so long as neither of us writes
// anything during the discussion or modifies any computer file
// during the discussion. I have violated neither the spirit nor
// letter of this restriction.

/**
 * @author Ethan Werner
 * @version 01.28.23
 * 
 *          Calculates the results of an expression
 */
public class ExpressionCalculator {
    /**
     * Calculates and prints the result of an expression
     * 
     * @param exp
     *            The expression being calculated
     * @return The string form of the expression with the solution
     */
    public String calculateResult(DLList<String> exp) {
        // Return an empty string if the expression is empty
        if (exp.isEmpty()) {
            return "";
        }

        String result = ""; // Contains the String to be returned

        // The list of numbers awaiting use for calculation
        DLList<BigNum> numList = new DLList<BigNum>();

        // Loop through the expression
        while (!exp.isEmpty()) {
            // The current number or operation
            String currString = exp.getHead().getData();

            exp.removeFront();

            // If currString is a number, add it to numList
            if (Character.isDigit(currString.charAt(0))) {
                // Temporary BigNum object
                BigNum tempNum = new BigNum(currString);
                numList.addBack(tempNum);
                // Uses the toString method to ensure proper format
                result += tempNum.toString() + " ";
            }
            // If currString is an operator, perform the appropriate calculation
            else {
                result += currString + " ";

                char op = currString.charAt(0); // The operation to be performed
                // If there are not enough numbers for the operator
                if (numList.getSize() < 2) {
                    // Print out the rest of the expression without
                    // further calculations
                    while (!exp.isEmpty()) {
                        currString = exp.getHead().getData();
                        exp.removeFront();
                        result += currString + " ";
                    }
                    return result + "=\n";
                }
                // If the operator is + -> Add the two most recent numbers
                else if (op == '+') {
                    // Contains the sum of the two most recent BigNum objects
                    BigNum temp = numList.getTail().getPrev().getData().add(
                        numList.getTail().getData());
                    numList.removeBack();
                    numList.getTail().setData(temp);
                }
                // If the operator is * -> Multiply the two most recent numbers
                else if (op == '*') {
                    // Contains the product of the two most recent BigNum
                    // objects
                    BigNum temp = numList.getTail().getPrev().getData()
                        .multiply(numList.getTail().getData());
                    numList.removeBack();
                    numList.getTail().setData(temp);
                }
                // If the operator is ^ -> Perform the appropriate exponential
                // operation on the two most recent numbers
                else if (op == '^') {
                    // Contains the result of the exponent function between the
                    // two most recent BigNum objects
                    BigNum temp = numList.getTail().getPrev().getData()
                        .exponent(numList.getTail().getData());
                    numList.removeBack();
                    numList.getTail().setData(temp);
                }
            }
        }

        result += "=";

        // If there is only one number left, print it as the answer
        if (numList.getSize() == 1) {
            return result + " " + numList.getHead().getData().toString() + "\n";
        }

        // Expression is unsolvable
        return result + "\n";
    }
}
