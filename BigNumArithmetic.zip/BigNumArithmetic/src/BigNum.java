// On my honor:
// - I have not used source code obtained from another student,
// or any other unauthorized source, either modified or
// unmodified.
//
// - All source code and documentation used in my program is
// either my original work, or was derived by me from the
// source code published in the textbook for this course.
//
// - I have not discussed coding details about this project
// with anyone other than my partner (in the case of a joint
// submission), instructor, ACM/UPE tutors or the TAs assigned
// to this course. I understand that I may discuss the concepts
// of this program with other students, and that another student
// may help me debug my program so long as neither of us writes
// anything during the discussion or modifies any computer file
// during the discussion. I have violated neither the spirit nor
// letter of this restriction.

/**
 * @author Ethan Werner
 * @version 01.26.23
 * 
 *          A class that can hold infinitely large numbers
 */
public class BigNum extends DLList<Integer> {

    private int carry = 0; // Holds the carry value from previous digits'
                           // addition. Used for add method and digitSum method.
                           // Tried using local variables and parameters, tried
                           // troubleshooting but nothing worked

    /**
     * New BigNum object
     * 
     * @param str
     *            The String form of the number to be stored
     */
    public BigNum(String str) {
        super();

        while (str.length() > 0) {
            addBack(Integer.parseInt(str.substring(0, 1)));
            str = str.substring(1);
        }
    }


    /**
     * New BigNum object
     */
    public BigNum() {
        super();
    }


    /**
     * Creates the String form of a BigNum object
     * 
     * @return The String form of a BigNum object
     */
    public String toString() {
        String str = ""; // The string form of a BigNum
        Node<Integer> curr = this.getHead(); // The current Node of the
                                             // iteration

        // Skips past any leading zeros
        while (curr != null && curr.getData() == 0) {
            curr = curr.getNext();
        }

        // Adds each digit to the return string
        while (curr != null) {
            str += curr.getData();
            curr = curr.getNext();
        }

        // If the return would be empty, return "0" instead
        if (str.equals("")) {
            return "0";
        }

        return str;
    }


    /**
     * Adds digits while calculating the carry value
     * Helper method for add
     * 
     * @param nums
     *            The numbers being added
     * @return The sum of nums and carry, modified based on the carry
     */
    private int digitSum(int nums) {
        int result = nums + carry;
        if (result < 10) {
            carry = 0;
        }
        else {
            result -= 10;
            carry = 1;
        }
        return result;
    }


    /**
     * Adds two BigNum objects
     * 
     * @param num
     *            The second number being added
     * @return The result of the addition
     */
    public BigNum add(BigNum num) {
        BigNum sum = new BigNum(); // The sum of the two BigNum objects
        // Loop through this until it is empty
        while (!this.isEmpty()) {

            // If num is empty
            if (num.isEmpty()) {
                // Loop through this until it is empty
                while (!this.isEmpty()) {
                    sum.addFront(digitSum(this.getTail().getData()));
                    this.removeBack();
                }

                // Add carry to the front of the sum
                if (carry != 0) {
                    sum.addFront(carry);
                    carry = 0;
                }
                return sum;
            }
            sum.addFront(digitSum(this.getTail().getData() + num.getTail()
                .getData()));
            this.removeBack();
            num.removeBack();
        }

        // Loop through this until it is empty
        while (!num.isEmpty()) {
            // Add each remaining digit of this to sum
            sum.addFront(digitSum(num.getTail().getData()));
            num.removeBack();
        }

        // Add carry to the front of the sum
        if (carry > 0) {
            sum.addFront(carry);
            carry = 0;
        }
        return sum;
    }


    /**
     * Multiplies two BigNum objects
     * 
     * @param num
     *            The second factor
     * @return The product of both BigNum objects
     */
    public BigNum multiply(BigNum num) {
        BigNum product = new BigNum(); // Stores the product of the two factors
        product.addFront(0);
        // For each digit in num
        Node<Integer> currNum = num.getTail(); // Current node in the iteration
                                               // of num
        int placeValueNum = 0; // The place value of the current node in num
        while (currNum != null) {
            BigNum sum = new BigNum("0"); // The sum of the current digit in num
                                          // multiplied by each digit in this

            Node<Integer> currThis = this.getTail(); // Current node in the
                                                     // iteration of this
            int placeValueThis = 0; // The place value of the current node in
                                    // this
            while (currThis != null) {
                // Holds a BigNum that multiplies currThis and currNum and adds
                // an appropriate amount of zeros
                BigNum temp = new BigNum("" + currThis.getData() * currNum
                    .getData());
                for (int i = 0; i < placeValueThis; i++) {
                    temp.addBack(0);
                }
                sum = sum.add(temp);
                currThis = currThis.getPrev();
                placeValueThis++;
            }
            for (int i = 0; i < placeValueNum; i++) {
                sum.addBack(0);
            }
            product = product.add(sum);
            currNum = currNum.getPrev();
            placeValueNum++;
        }
        return product;
    }


    /**
     * Halves a BigNum to assist in the exponent method
     * 
     * @return Half of this
     */
    private BigNum half() {
        BigNum half = this.multiply(new BigNum("5")); // Stores this as it is
                                                      // being halved
        half.removeBack();
        return half;
    }


    /**
     * Calculates the result of this BigNum to the power of a another BigNum
     * 
     * @param power
     *            The power this is being raised to
     * @return The result of this BigNum to the power of a another BigNum
     */
    public BigNum exponent(BigNum power) {
        // Base case -> Power is 0
        if (power.toString().equals("0")) {
            return new BigNum("1");
        }
        // Recursive case -> Power is even
        else if (power.getTail().getData() % 2 == 0) {
            return this.multiply(this).exponent(power.half());
        }
        // Recursive case -> Power odd
        else {
            power.getTail().setData(power.getTail().getData() - 1);
            return this.multiply(this.exponent(power));
        }
    }
}
