// On my honor:
// - I have not used source code obtained from another student,
// or any other unauthorized source, either modified or
// unmodified.
//
// - All source code and documentation used in my program is
// either my original work, or was derived by me from the
// source code published in the textbook for this course.
//
// - I have not discussed coding details about this project
// with anyone other than my partner (in the case of a joint
// submission), instructor, ACM/UPE tutors or the TAs assigned
// to this course. I understand that I may discuss the concepts
// of this program with other students, and that another student
// may help me debug my program so long as neither of us writes
// anything during the discussion or modifies any computer file
// during the discussion. I have violated neither the spirit nor
// letter of this restriction.

import student.TestCase;

/**
 * @author Ethan Werner
 * @version 01.28.23
 * 
 *          Tests the functionality of the ExpressionCalculator class
 */
public class ExpressionCalculatorTest extends TestCase {

    // Objects to be used during the testing of the ExpressionCalculator class
    private ExpressionCalculator expCalc;
    private DLList<String> exp;

    /**
     * Sets up to test the functionality of the ExpressionCalculator class
     */
    @Override
    public void setUp() {
        expCalc = new ExpressionCalculator();
        exp = new DLList<String>();
    }


    /**
     * Tests a solvable expression
     */
    public void testSolvableExpression() {
        exp.addBack("000000056669777");
        exp.addBack("99999911111");
        exp.addBack("+");
        exp.addBack("352324012");
        exp.addBack("+");
        exp.addBack("03");
        exp.addBack("^");
        exp.addBack("555557778");
        exp.addBack("*");

        assertEquals(
            "56669777 99999911111 + 352324012 + 3 ^ 555557778 * ="
            + " 562400792227677956625810678708149922000000\n",
            expCalc.calculateResult(exp));
    }


    /**
     * Tests an expression containing to many numbers
     */
    public void testTooManyNumbers() {
        exp.addBack("5555555");
        exp.addBack("333333");
        exp.addBack("5454353");
        exp.addBack("999999");
        exp.addBack("666666");
        exp.addBack("1");
        exp.addBack("^");
        exp.addBack("*");
        exp.addBack("*");
        exp.addBack("+");
        assertEquals("5555555 333333 5454353 999999 666666 1 ^ * * + =\n",
            expCalc.calculateResult(exp));
    }


    /**
     * Tests an expression containing to many operators
     */
    public void testTooManyOperators() {
        exp.addBack("3432");
        exp.addBack("3333");
        exp.addBack("9999");
        exp.addBack("+");
        exp.addBack("*");
        exp.addBack("^");
        exp.addBack("*");
        exp.addBack("*");
        exp.addBack("6666");
        exp.addBack("+");
        assertEquals("3432 3333 9999 + * ^ * * 6666 + =\n",
            expCalc.calculateResult(exp));
    }
    
    
    /**
     * Tests misc cases
     */
    public void testMiscCases() {
        exp.clear();
        assertEquals("", expCalc.calculateResult(exp));
        
        exp.clear();
        exp.addBack("3432");
        assertNotSame("", expCalc.calculateResult(exp));
        
        exp.clear();
        exp.addBack("4");
        exp.addBack("2");
        exp.addBack("^");
        assertEquals("4 2 ^ = 16\n", expCalc.calculateResult(exp));
    }
}
