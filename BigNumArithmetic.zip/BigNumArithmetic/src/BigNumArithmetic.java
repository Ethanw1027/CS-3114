// On my honor:
// - I have not used source code obtained from another student,
// or any other unauthorized source, either modified or
// unmodified.
//
// - All source code and documentation used in my program is
// either my original work, or was derived by me from the
// source code published in the textbook for this course.
//
// - I have not discussed coding details about this project
// with anyone other than my partner (in the case of a joint
// submission), instructor, ACM/UPE tutors or the TAs assigned
// to this course. I understand that I may discuss the concepts
// of this program with other students, and that another student
// may help me debug my program so long as neither of us writes
// anything during the discussion or modifies any computer file
// during the discussion. I have violated neither the spirit nor
// letter of this restriction.

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author Ethan Werner
 * @version 01.28.23
 * 
 *          Contains the main method to run the full BigNumArithmetic program
 */
public class BigNumArithmetic {

    /**
     * Reads in each line, then calculates and prints the results
     * 
     * @param args
     *            The array of String arguments provided
     * @throws FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        // File containing expressions to be calculated
        File input = new File(args[0]);

        // One line of input (a full expression)
        DLList<String> exp = new DLList<String>(); 
        Scanner scan = new Scanner(input); // Reads in each line

        while (scan.hasNextLine()) {
            String lineRead = scan.nextLine(); // A full line of input
            Scanner thisLine = new Scanner(lineRead); // Reads in each token
            // from a line

            while (thisLine.hasNext()) { // Adds each token to the stack
                exp.addBack(thisLine.next());
            }
            thisLine.close();

            // Calculates and prints an expression's results
            ExpressionCalculator expCalc = new ExpressionCalculator();
            System.out.print(expCalc.calculateResult(exp));
        }
        scan.close();
    }
}