// On my honor:
// - I have not used source code obtained from another student,
// or any other unauthorized source, either modified or
// unmodified.
//
// - All source code and documentation used in my program is
// either my original work, or was derived by me from the
// source code published in the textbook for this course.
//
// - I have not discussed coding details about this project
// with anyone other than my partner (in the case of a joint
// submission), instructor, ACM/UPE tutors or the TAs assigned
// to this course. I understand that I may discuss the concepts
// of this program with other students, and that another student
// may help me debug my program so long as neither of us writes
// anything during the discussion or modifies any computer file
// during the discussion. I have violated neither the spirit nor
// letter of this restriction.

import student.TestCase;

/**
 * @author Ethan Werner
 * @version 01.26.23
 * 
 *          Tests the methods of the DLList class
 */
public class DLListTest extends TestCase {

    private DLList<String> list; // The list used for tests

    /**
     * Sets up to test the methods of the DLList class
     */
    @Override
    public void setUp() {
        list = new DLList<String>();
    }


    /**
     * Tests the isEmpty method
     */
    public void testIsEmpty() {
        assertTrue(list.isEmpty());

        list.addFront("test");
        assertFalse(list.isEmpty());
    }


    /**
     * Tests the getHead method
     */
    public void testGetHead() {
        assertNull(list.getHead());

        list.addFront("test");
        assertEquals("test", list.getHead().getData());
    }


    /**
     * Tests the getTail method
     */
    public void testGetTail() {
        assertNull(list.getTail());

        list.addFront("test");
        assertEquals("test", list.getTail().getData());
    }


    /**
     * Tests the addFront method
     */
    public void testAddFront() {
        list.addFront("test1");
        assertEquals("test1", list.getHead().getData());
        assertFalse(list.isEmpty());
        assertEquals(list.getSize(), 1);

        list.addFront("test2");
        assertEquals("test2", list.getHead().getData());
        assertEquals("test1", list.getHead().getNext().getData());
        assertEquals(list.getSize(), 2);
    }


    /**
     * Tests the addBack method
     */
    public void testAddBack() {
        list.addBack("test1");
        assertEquals("test1", list.getHead().getData());
        assertFalse(list.isEmpty());
        assertEquals(list.getSize(), 1);

        list.addBack("test2");
        assertEquals("test1", list.getHead().getData());
        assertEquals("test2", list.getHead().getNext().getData());
        assertEquals(list.getSize(), 2);
    }


    /**
     * Tests the removeFront method
     */
    public void testRemoveFront() {
        assertFalse(list.removeFront());
        assertEquals(list.getSize(), 0);

        list.addFront("test1");
        assertTrue(list.removeFront());
        assertNull(list.getHead());
        assertNull(list.getTail());
        assertEquals(list.getSize(), 0);

        list.addFront("test1");
        list.addBack("test2");
        list.addBack("test3");
        assertTrue(list.removeFront());
        assertEquals("test2", list.getHead().getData());
        assertNull(list.getHead().getPrev());
        assertEquals(list.getSize(), 2);
    }


    /**
     * Tests the removeBack method
     */
    public void testRemoveBack() {
        assertFalse(list.removeBack());
        assertEquals(list.getSize(), 0);

        list.addFront("test1");
        assertTrue(list.removeBack());
        assertNull(list.getHead());
        assertNull(list.getTail());
        assertEquals(list.getSize(), 0);

        list.addFront("test1");
        list.addBack("test2");
        list.addBack("test3");
        assertTrue(list.removeBack());
        assertEquals("test1", list.getHead().getData());
        assertNull(list.getTail().getNext());
        assertEquals(list.getSize(), 2);
    }

}
