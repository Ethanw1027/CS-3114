// On my honor:
// - I have not used source code obtained from another student,
// or any other unauthorized source, either modified or
// unmodified.
//
// - All source code and documentation used in my program is
// either my original work, or was derived by me from the
// source code published in the textbook for this course.
//
// - I have not discussed coding details about this project
// with anyone other than my partner (in the case of a joint
// submission), instructor, ACM/UPE tutors or the TAs assigned
// to this course. I understand that I may discuss the concepts
// of this program with other students, and that another student
// may help me debug my program so long as neither of us writes
// anything during the discussion or modifies any computer file
// during the discussion. I have violated neither the spirit nor
// letter of this restriction.

/**
 * @author Ethan Werner
 * @version 01.26.23
 * 
 *          Doubly Linked Node Class
 * 
 * @param <E>
 *            The data type stored in the Node
 */
public class Node<E> {
    private Node<E> prev; // The previous Node in sequence
    private Node<E> next; // The next Node in sequence
    private E data; // The Node's stored data

    /**
     * Constructor with no parameters
     */
    public Node() {
        data = null;
        prev = null;
        next = null;
    }


    /**
     * Constructor with a data value
     * 
     * @param value
     *            The value to be stored in the new node
     */
    public Node(E value) {
        data = value;
        prev = null;
        next = null;
    }


    /**
     * Gets the previous node
     * 
     * @return The previous node
     */
    public Node<E> getPrev() {
        return prev;
    }


    /**
     * Gets the next node
     * 
     * @return The next node
     */
    public Node<E> getNext() {
        return next;
    }


    /**
     * Gets the node's data
     * 
     * @return The data stored in the node
     */
    public E getData() {
        return data;
    }


    /**
     * Sets the previous Node
     * 
     * @param newNode
     *            The new previous Node
     */
    public void setPrev(Node<E> newNode) {
        prev = newNode;
    }


    /**
     * Sets the next Node
     * 
     * @param newNode
     *            The new next Node
     */
    public void setNext(Node<E> newNode) {
        next = newNode;
    }


    /**
     * Changes the data stored in the Node
     * 
     * @param newValue
     *            The new data being stored
     */
    public void setData(E newValue) {
        data = newValue;
    }
}
