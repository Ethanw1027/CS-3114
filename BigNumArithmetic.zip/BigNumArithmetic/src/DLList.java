// On my honor:
// - I have not used source code obtained from another student,
// or any other unauthorized source, either modified or
// unmodified.
//
// - All source code and documentation used in my program is
// either my original work, or was derived by me from the
// source code published in the textbook for this course.
//
// - I have not discussed coding details about this project
// with anyone other than my partner (in the case of a joint
// submission), instructor, ACM/UPE tutors or the TAs assigned
// to this course. I understand that I may discuss the concepts
// of this program with other students, and that another student
// may help me debug my program so long as neither of us writes
// anything during the discussion or modifies any computer file
// during the discussion. I have violated neither the spirit nor
// letter of this restriction.

/**
 * @author Ethan Werner
 * @version 01.26.23
 * 
 *          Doubly Linked List Class
 * 
 * @param <E>
 *            The data type of the DLList
 */
public class DLList<E> {

    private int size; // The size of the list
    private Node<E> head; // The front Node of the list
    private Node<E> tail; // The back Node of the list

    /**
     * New DLList object
     */
    public DLList() {
        size = 0;
        head = null;
        tail = null;
    }


    /**
     * Checks if the list is empty
     * 
     * @return True if empty, otherwise false
     */
    public boolean isEmpty() {
        return (size == 0);
    }


    /**
     * Gets the head of the list
     * 
     * @return The head Node
     */
    public Node<E> getHead() {
        return head;
    }


    /**
     * Gets the tail of the list
     * 
     * @return The tail Node
     */
    public Node<E> getTail() {
        return tail;
    }


    /**
     * Gets the size of the list
     * 
     * @return The list's size
     */
    public int getSize() {
        return size;
    }


    /**
     * Adds a Node to the front of the list
     * 
     * @param newValue
     *            The new value being added
     */
    public void addFront(E newValue) {
        Node<E> newNode = new Node<E>(newValue);
        // List is empty
        if (isEmpty()) {
            tail = newNode;
        }
        // List contains other Nodes
        else {
            head.setPrev(newNode);
            newNode.setNext(head);
        }
        head = newNode;
        size++;
    }


    /**
     * Adds a Node to the back of the list
     * 
     * @param newValue
     *            The new value being added
     */
    public void addBack(E newValue) {
        Node<E> newNode = new Node<E>(newValue);
        // List is empty
        if (isEmpty()) {
            head = newNode;
        }
        // List contains other Nodes
        else {
            tail.setNext(newNode);
            newNode.setPrev(tail);
        }
        tail = newNode;
        size++;
    }


    /**
     * Clears the entire list
     */
    public void clear() {
        size = 0;
        head = null;
        tail = null;
    }


    /**
     * Removes the front value from the list
     * 
     * @return True if successful, otherwise false
     */
    public boolean removeFront() {
        // Only one Node in the list
        if (isEmpty()) {
            return false;
        }
        // Only one Node in the list
        else if (size == 1) {
            clear();
            return true;
        }
        // List has multiple values
        else {
            head = head.getNext();
            head.setPrev(null);
            size--;
            return true;
        }
    }


    /**
     * Removes the back value from the list
     * 
     * @return True if successful, otherwise false
     */
    public boolean removeBack() {
        // List is empty -> Cannot remove
        if (isEmpty()) {
            return false;
        }
        // Only one Node in the list
        else if (head.getNext() == null) {
            clear();
            return true;
        }
        // List has multiple values
        else {
            tail = tail.getPrev();
            tail.setNext(null);
            size--;
            return true;
        }
    }
}
